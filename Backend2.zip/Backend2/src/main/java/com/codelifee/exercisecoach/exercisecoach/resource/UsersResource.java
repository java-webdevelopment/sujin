package com.codelifee.exercisecoach.exercisecoach.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codelifee.exercisecoach.exercisecoach.mapper.UsersMapper;
import com.codelifee.exercisecoach.exercisecoach.model.Users;

@RestController
@RequestMapping("/rest/users")
@CrossOrigin(origins="http://localhost:5000")
public class UsersResource {

	private UsersMapper usersMapper;
			
	@Autowired
	public UsersResource(UsersMapper usersMapper) {
		this.usersMapper = usersMapper;
	}

	@GetMapping("/all")
	public List<Users> getAll() {
		return usersMapper.findAll();
	}
	
	@GetMapping("/user/{id}")
	public Users getUsers(@PathVariable("id")String id) {
		return usersMapper.getUsers(id);
	}
	
	@PutMapping("/users/{id}")
	public void createUsers(@PathVariable("id")String id, @PathVariable("password")String password,
			@RequestParam("name")String name, @RequestParam("birth")String birth, @PathVariable("mobile")String mobile,
			@PathVariable("sex")String sex, @RequestParam("address") String address) {
		usersMapper.insertUsers(id, password, name, birth, mobile, sex, address);
	}
	
	@PostMapping("/users/{id}")
	public void updateUsers(@PathVariable("id")String id, @PathVariable("password")String password,
			@RequestParam("name")String name, @RequestParam("birth")String birth, @PathVariable("mobile")String mobile,
			@PathVariable("sex")String sex, @RequestParam("address") String address) {
		usersMapper.updateUsers(id, password, name, birth, mobile, sex, address);
	}
	
	@DeleteMapping("/users/{id}")
	public void deleteUsers(@PathVariable("id")String id) {
		usersMapper.deleteUsers(id);
	}
}
