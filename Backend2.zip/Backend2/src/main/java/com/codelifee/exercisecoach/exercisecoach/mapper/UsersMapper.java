package com.codelifee.exercisecoach.exercisecoach.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.codelifee.exercisecoach.exercisecoach.model.Users;

@Mapper
public interface UsersMapper {

	@Select("select * from users")
	List<Users> findAll();
	
	@Select("SELECT * FROM UserProfile WHERE id=#{id}")
	Users getUsers(@Param("id")String id);
	
	@Insert("INSERT INTO User VALUES(#{id},#{password},#{name},#{birth},#{email},#{sex},#{mobile},#{address})")
	int insertUsers(@Param("id")String id, @Param("password")String password, @Param("name")String name,
			@Param("birth")String birth, @Param("mobile")String mobile, 
			@Param("sex")String sex, @Param("address") String address);
	
	@Update("UPDATE User SET id=#{id},password=#{password},name=#{name},birth=#{birth},"
			+ "email=#{email},sex=#{sex},mobile=#{mobile},address=#{address} WHERE id=#{id}")
	int updateUsers(@Param("id")String id, @Param("password")String password, @Param("name")String name,
			@Param("birth")String birth, @Param("mobile")String mobile, 
			@Param("sex")String sex, @Param("address") String address);
	
	@Delete("DELETE FROM User WHERE id=#{id}")
	int deleteUsers(@Param("id")String id);
	
}
