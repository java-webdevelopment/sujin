package com.codelifee.exercisecoach.exercisecoach;

import org.junit.jupiter.api.Test;

class ExerciseCoachApplicationTests {

	@Test
	void contextLoads() {
	}

}
